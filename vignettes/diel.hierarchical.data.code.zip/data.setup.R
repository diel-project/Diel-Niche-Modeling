# Data setup for vignette


# Load data: Coyote/Wolf Species interactions
dat <- read.csv("data_input/species_records.csv", as.is = TRUE) %>% 
  filter(c(Species == "Coyote" | Species == "Wolf")) %>% droplevels() %>%  
  mutate(DateTimeOriginal = ymd_hm(DateTimeOriginal))
cov <- read.csv("data_input/CameraTrapProject_CT_data_for_analysis_MASTER.csv", as.is = TRUE) %>% 
  select(c(Session, Site, Date_setup, Date_retr, Problem1_from, Problem1_to)) %>% 
  mutate(Date_setup = mdy(Date_setup),
         Date_retr = mdy(Date_retr),
         Problem1_from = mdy(Problem1_from),
         Problem1_to = mdy(Problem1_to)
  ) 

#BDG- subsetting
dat1 = subset(dat, Date > "2016-05-01" & Date < "2016-07-07")
dat2 = subset(dat, Date > "2017-05-01" & Date < "2017-07-07")
dat3 = subset(dat, Date > "2018-05-01" & Date < "2018-07-07")

nrow(dat1)
nrow(dat2)

cov1 = subset(cov, Date_setup > "2016-05-01" & Date_retr < "2016-07-07")
cov2 = subset(cov, Date_setup > "2017-05-01" & Date_retr < "2017-07-07")
cov3 = subset(cov, Date_setup > "2018-05-01" & Date_retr < "2018-07-07")

cov=rbind(cov1,cov2,cov3)
dat=rbind(dat1,dat2,dat3)


#################
# Where both species were detected at the same site during a session?
# List sites with at least a detection on a given session
site_Co <- dat %>% filter(Species == "Coyote") %>% group_by(Session, Station) %>% 
  summarize(n = n()) 
site_Wo <- dat %>% filter(Species == "Wolf") %>% group_by(Session, Station) %>% 
  summarize(n = n()) 
site <- semi_join(site_Co, site_Wo, by = c("Session", "Station")) %>% 
  mutate(Sess_site = paste(Session, Station, sep = "_"))


##################
# Add binary variable for presence of other species
dat$oth_sp <- NA
for(i in 1:nrow(dat)){
  dat$oth_sp[i] <- ifelse(paste(dat$Session[i], dat$Station[i], sep = "_") %in% site$Sess_site, 1,0)
}
table(dat$Species, dat$oth_sp)

###################

# Prepare data for model-based methods
# Merge time of deployment and retrieval + problems
site_Co2 <- cov
site_Co2$end <- ymd("2000-01-01")
for(i in 1:nrow(site_Co2)){
  site_Co2$end[i] <-  min(site_Co2$Date_retr[i], 
                          site_Co2$Problem1_from[i], 
                          na.rm = TRUE
  )
}

# Create dataframe to store captures 
occasions_Co <- vector("list", length = nrow(site_Co2))
for(i in 1:nrow(site_Co2)){
  occasions_Co[[i]] <- data.frame(Session = site_Co2$Session[i],
                                  site = site_Co2$Site[i],
                                  start = seq(from = ymd_hms(paste(site_Co2$Date_setup[i], "00:00:00", sep = " ")), 
                                              to = ymd_hms(paste(site_Co2$end[i], "23:59:59", sep = " ")), by = '60 min')
  ) %>% 
    mutate(end = c(start[2:length(start)], 
                   start[length(start)]+minutes(60)
    )
    ) 
}
occasions_Co <- do.call(rbind.data.frame, occasions_Co)
occasions_Co$capt <- 0
occasions_Wo <- occasions_Co

#####################
# Coyote data:
# Store captures
dat_Co <- dat %>% filter(Species == "Coyote")
for(i in 1:nrow(dat_Co)){
  occasions_Co[occasions_Co$Session == as.character(dat_Co$Session[i]) &
                 occasions_Co$site == as.character(dat_Co$Station[i]) &
                 occasions_Co$start <= dat_Co$DateTimeOriginal[i] & 
                 occasions_Co$end > dat_Co$DateTimeOriginal[i], "capt"] <- 1
}

# Format data 
occasions_Co$Time <- hour(occasions_Co$start)
occasions_Co$oth_sp <- NA
for(i in 1:nrow(occasions_Co)){
  occasions_Co$oth_sp[i] <- ifelse(paste(occasions_Co$Session[i], occasions_Co$site[i], sep = "_") %in% site$Sess_site, 1,0)
}
table(occasions_Co$oth_sp, occasions_Co$capt)
occasions_Co$site <- as.factor(occasions_Co$site)
occasions_Co$oth_sp <- as.factor(occasions_Co$oth_sp)

# format data for cbind(success, failure)
occasions_Co_cbind <- occasions_Co %>% 
  group_by(site, Time, oth_sp) %>% 
  summarize(success = sum(capt),
            failure = n() - success)

########################


# Store captures
dat_Wo <- dat %>% filter(Species == "Wolf")
for(i in 1:nrow(dat_Wo)){
  occasions_Wo[occasions_Wo$Session == as.character(dat_Wo$Session[i]) &
                 occasions_Wo$site == as.character(dat_Wo$Station[i]) &
                 occasions_Wo$start <= dat_Wo$DateTimeOriginal[i] & 
                 occasions_Wo$end > dat_Wo$DateTimeOriginal[i], "capt"] <- 1
}

# Format data 
occasions_Wo$Time <- hour(occasions_Wo$start)
occasions_Wo$oth_sp <- NA
for(i in 1:nrow(occasions_Wo)){
  occasions_Wo$oth_sp[i] <- ifelse(paste(occasions_Wo$Session[i], occasions_Wo$site[i], sep = "_") %in% site$Sess_site, 1,0)
}
table(occasions_Wo$oth_sp, occasions_Wo$capt)
occasions_Wo$site <- as.factor(occasions_Wo$site)
occasions_Wo$oth_sp <- as.factor(occasions_Wo$oth_sp)

# format data for cbind(success, failure)
occasions_Wo_cbind <- occasions_Wo %>% 
  group_by(site, Time, oth_sp) %>% 
  summarize(success = sum(capt),
            failure = n() - success)


save.image(file = "coywolf.data.summer.RData")

